First, a note of caution:
The branching test was tested on the staff gitlet. There is a possibility that it'll incorrectly fail with a correct gitlet implementation. From what I've seen, it's even possible that the staff gitlet differs from the autograder, but I'm not sure about that at all. (If this turns out to be the case we're flooding ed) I would be glad if someone with a working gitlet implementation could verify if this test succeeds for them.

The status EC test was tested with both my own gitlet implementation and the staff gitlet, passing on both. Although I'm fairly certain my `status` implementation is correct, I can't be 100% sure since I haven't submitted to the autograder yet.

About the tests:
The status EC test will test both the EC and non-EC portions of `status`. It will also test basically every possible case in which a file can appear in each category, so it should be quite comprehensive.

The branching test covers a lot of edge cases surrounding `branch`, `rm-branch`, `checkout` (for branches), and `reset`. However, it will use every command other than `merge`, EC commands, and status EC. Should also be quite comprehensive, but it might be possible to create a really stupid gitlet implementation that passes this test but doesn't actually work.

How to use:
Put `test05-status.in` and `test07-branching-thorough.in` wherever you want in your testing directory. Make sure the files in `alskdfjsod.zip` are in `src`. Then proceed to run those tests like normal. Have fun (or suffer idk).